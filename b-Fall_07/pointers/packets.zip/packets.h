// Packets.h
// Required to compile

int packData(char[], int, char*[]);
int unpackData(char[]);
char* receivePacket();
char* getNewEmptyPacket();
int getMsgNumber();
